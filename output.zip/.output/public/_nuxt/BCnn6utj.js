import{O as s}from"./CDUQJvRv.js";const t=s("/images/logos/pocketnuxt.svg");export{t as _};
